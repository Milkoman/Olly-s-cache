#include "People.hpp"
#include <string>

int People::getBirthDay() const
{
	return std::stoi(bday.substr(3, 2));
}

int People::getBirthMonth() const
{
	return std::stoi(bday.substr(0, 2));
}

int People::getBirthYear() const
{
	return std::stoi(bday.substr(6, 4));
}

bool People::operator>(const People &right)
{
	bool status = false;
	if (name > right.name)
		status = true;

	return status;
}

bool People::operator==(const People &r)
{
	return name == r.getName() && bday == r.getBday();
}

bool People::bDayGreater(const People &r) const
{
	if (getBirthYear() > r.getBirthYear()) {
		return true;
	}
	else if (getBirthYear() == r.getBirthYear()) {
		if (getBirthMonth() > r.getBirthMonth()) {
			return true;
		}
		else if (getBirthMonth() == r.getBirthMonth()) {
			if (getBirthDay() > r.getBirthDay()) {
				return true;
			}
		}
	}

	return false;
	
}

ostream & operator<<(ostream & strm, const People & obj)
{
	strm << obj.getName() << " " << obj.getBday();
	return strm;
}
