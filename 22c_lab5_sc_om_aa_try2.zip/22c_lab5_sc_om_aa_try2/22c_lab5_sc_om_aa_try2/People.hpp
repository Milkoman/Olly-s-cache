#ifndef PEOPLE_H
#define PEOPLE_H
#include <string>

using std::string;
using std::ostream;

class People;
ostream &operator<< (ostream &, const People &);

class People
{
	private:
		string name;
		string bday;

	public:
		People(string str = "Empty", string date = "00/00/0000") { name = str; bday = date; }
		void setName(const string n) { name = n; }
		void setBday(const string x) { bday = x; }
		string getName() const { return name; }
		string getBday() const { return bday; }
		int getBirthDay() const;
		int getBirthMonth() const;
		int getBirthYear() const;

		bool operator> (const People &);
		bool operator== (const People &);
		bool bDayGreater(const People &) const;
		friend ostream &operator<< (ostream &, const People &);
};

#endif
