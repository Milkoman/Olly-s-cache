#include "BinaryNode.hpp"
#include "BinaryTree.hpp"
#include "AVLTree.hpp"
#include "People.hpp"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

string OUTFILENAME1 = "NamesOutput.txt";
string OUTFILENAME2 = "BirthdaysOutput.txt";
string INPUTFILENAME = "InputData.txt";


template<class T>
void display(T str)
{

	cout << str << " ";
}

template<class T>
void displayIndent(T str, int n)
{
	for (int i = 0; i < n - 1; i++) {
		cout << "\t";
	}
	cout << str << endl;
}

template <class T>
void write(T data, std::ostream &outF)
{
	outF << data << " ";
}

bool LRCmpDate(People a, People b) {
	return a.bDayGreater(b);
}


int main()
{
	ofstream of1;
	ofstream of2;
	ifstream infile;
	infile.open(INPUTFILENAME);
	of1.open(OUTFILENAME1);
	of2.open(OUTFILENAME2);
	string input;
	string input2;
	BinaryTree<People> btree;
	BinaryTree<People> ntree;
	while (getline(infile, input, '\n') && getline(infile, input2, '\n'))
	{
		People dude(input, input2);
		ntree.add(dude);
		btree.add(dude, LRCmpDate);

	}
	infile.close();

	cout << "Name based BST:\n";

	cout << "Preorder: ";
	of1 << "Preorder: ";

	ntree.preorderTraverse(display);
	ntree.preorderTraverse(write, of1);

	cout << "\nPostorder: ";
	of1 << ("\nPostorder: ");
	ntree.postorderTraversal(display);
	ntree.postorderTraversal(write, of1);

	cout << "\n\nBirthday based BST:";

	cout << "\nInorder: ";
	of2 << "Inorder: ";
	btree.inorderTraverse(display);
	btree.inorderTraverse(write, of2);



	cout << "\nBreadthFirst: ";
	of2 << "\nBreadthFirst: ";
	btree.breadthFirstTraversal(display);
	btree.breadthFirstTraversal(write, of2);

	of1.close();
	of2.close();

	cout << endl << endl;
	system("pause");
	return 0;
}